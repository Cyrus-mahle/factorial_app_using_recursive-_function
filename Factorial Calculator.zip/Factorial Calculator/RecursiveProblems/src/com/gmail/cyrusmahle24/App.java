package com.gmail.cyrusmahle24;
import java.util.Scanner;
import javax.swing.JOptionPane;
public class App {

	public static void main(String[] args) {
		 Factorial obj = new Factorial();
		 String num = JOptionPane.showInputDialog("Enter Number");
		 int num1 = Integer.parseInt(num);
		 JOptionPane.showMessageDialog(null,"Factorial of number entered is "+obj.fact(num1));
		 
	}


}
