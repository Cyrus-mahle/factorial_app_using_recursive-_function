package com.gmail.cyrusmahle24;
import java.util.Scanner;
public class Factorial {
	
private int num;



int fact(int num) {
	
	if(num==0) {
		return 1;
	}
	else {
		return num*fact(num-1);
	}
	
}

public int getNum() {
	
	return num;
	

}

public void setNum(int num) {
	this.num = num;
}




}